#include "noncanmode.h"
#include <ostream>
int main(){
	std::cout << "Hello World\n";
}